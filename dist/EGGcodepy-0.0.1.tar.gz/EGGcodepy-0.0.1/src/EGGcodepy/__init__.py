from EGGcodepy.EGGcodepy import Egg as EGGcodepy

